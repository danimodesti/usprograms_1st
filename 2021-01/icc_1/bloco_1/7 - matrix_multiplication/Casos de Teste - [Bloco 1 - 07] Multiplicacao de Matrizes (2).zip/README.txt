Arquivo zip gerado em: 05/08/2021 02:00:19 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Bloco 1 - 07] Multiplicação de Matrizes